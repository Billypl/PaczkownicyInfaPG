----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/24/2025 07:43:58 PM
-- Design Name: 
-- Module Name: testbench - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity testbench is
--  Port ( );
end testbench;

architecture Behavioral of testbench is

component top is
    Port ( clk_i : in STD_LOGIC;
           rst_i : in STD_LOGIC;
           button_i : in STD_LOGIC_VECTOR (3 downto 0);
           led7_an_o : out STD_LOGIC_VECTOR (3 downto 0);
           led7_seg_o : out STD_LOGIC_VECTOR (7 downto 0));
end component;

signal clk, rst : STD_LOGIC := '0';
signal button: STD_LOGIC_VECTOR(3 downto 0) := "0000";
signal led7_an: STD_LOGIC_VECTOR(3 downto 0);
signal led7_seg: STD_LOGIC_VECTOR(7 downto 0);

begin

t: top port map (
    clk_i => clk,
    rst_i => rst,
    button_i => button,
    led7_an_o => led7_an,
    led7_seg_o => led7_seg
);

clk <= not clk after 5 ns;

sim: process
begin
    rst <= '1';
    wait for 20 ns;
    rst <= '0';
    wait for 100ns;
    
    button <= "0010";
    wait for 1ms;
    button <= "0000";
    wait for 1ms;
    
    button <= "0010";
    wait for 1ms;
    button <= "0000";
    wait for 1ms;
    
    button <= "0010";
    wait for 1ms;
    button <= "0000";
    wait for 1ms;
    
    button <= "0001";
    wait for 1ms;
    button <= "0000";
    wait for 1ms;
    
    button <= "1000";
    wait for 1ms;
    button <= "0000";
    wait for 1ms;
    
    button <= "0010";
    wait for 1ms;
    button <= "0000";
    wait for 1ms;
end process;

end Behavioral;
