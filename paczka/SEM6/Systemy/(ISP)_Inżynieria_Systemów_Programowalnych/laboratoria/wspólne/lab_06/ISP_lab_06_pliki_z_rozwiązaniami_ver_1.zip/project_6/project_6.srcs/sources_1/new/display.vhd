----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 03/19/2025 10:44:21 AM
-- Design Name: 
-- Module Name: display - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity display is
    Port ( clk_i : in STD_LOGIC;
           rst_i : in STD_LOGIC;
           digit_i : in STD_LOGIC_VECTOR (31 downto 0);
           led7_an_o : out STD_LOGIC_VECTOR (3 downto 0);
           led7_seg_o : out STD_LOGIC_VECTOR (7 downto 0));
end display;

architecture Behavioral of display is

signal div_counter: unsigned (31 downto 0) := (others => '0');
signal div_clk: std_logic := '0';
signal digit_counter: unsigned (1 downto 0) := "00";

begin

dzielnik: process (clk_i, rst_i) is
begin
    if rst_i = '1' then
        div_counter <= (others => '0');
        div_clk <= '0';
    elsif rising_edge(clk_i) then
        div_counter <= div_counter + 1;
        if div_counter = 50000 then
            div_clk <= '1';
        elsif div_counter = 99999 then
            div_clk <= '0';
            div_counter <= (others => '0');
        end if;
    end if;
end process dzielnik;

disp: process (div_clk, rst_i) is
begin
    if rst_i = '1' then
        led7_an_o <= (others => '0');
        led7_seg_o <= (others => '0');
        digit_counter <= "00";
    elsif rising_edge(div_clk) then
        if digit_counter = 0 then
            led7_an_o <= "1110";
            led7_seg_o <= digit_i(7 downto 0);
        elsif digit_counter = 1 then
            led7_an_o <= "1101";
            led7_seg_o <= digit_i(15 downto 8);
        elsif digit_counter = 2 then
            led7_an_o <= "1011";
            led7_seg_o <= digit_i(23 downto 16);
        elsif digit_counter = 3 then
            led7_an_o <= "0111";
            led7_seg_o <= digit_i(31 downto 24);
        end if;
        digit_counter <= digit_counter + 1;
    end if;
end process disp;

end Behavioral;
