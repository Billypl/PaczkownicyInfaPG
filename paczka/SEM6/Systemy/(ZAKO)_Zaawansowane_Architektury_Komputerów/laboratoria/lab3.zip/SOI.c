#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

#define N 32 //Liczba pr�bek wej�ciowych
#define L 16 //D�ugo�� lini op�niaj�cej

uint32_t input[N] = {
	1,2,3,4,5,6,7,8,
	9,10,11,12,13,14,15,16,
	17,18,19,20,21,22,23,24,
	25,26,27,28,29,30,31,32
};

uint32_t delay[L] = {
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0
};

//Stan lini op�niaj�cej, gdy nie zostanie wyczyszczona po poprzednich obliczeniach
//uint32_t delay[L] = { 
//	17,32,31,30,29,28,27,26,
//	25,24,23,22,21,20,19,18
//};

uint32_t coeff[L] = {
	1,1,1,1,1,1,1,1,
	1,1,1,1,1,1,1,1
};

uint32_t output[N] = {
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0
};

int main() {
	int delay_begin = 0; //R4 / 4 
	int i; //R1 / 4

	for (i = 0; i < N; i++) {
		int j; //R2 * 4
		uint32_t sum = 0; //R3
		int delay_ind = delay_begin; //R5 / 4
		uint32_t tmp = input[i]; //R7
		delay[delay_begin] = tmp;

		for (j = 0; j < L; j++) {
			uint32_t data_value = delay[delay_ind]; //R9
			uint32_t coeff_value = coeff[j]; //R10
			sum = sum + data_value * coeff_value; //Tutaj mo�na umie�ci� instrukcj� ADDMUL :)

			delay_ind++;
			if (delay_ind >= L)
				delay_ind = 0;
		}
		output[i] = sum;
		delay_begin--;
		if (delay_begin < 0)
			delay_begin = L - 1;
	}

	//Koniec implmenetacji filtru

	printf("Wyniki dec:\n");
	for (i = 0; i < N; i = i + 4) {
		printf("%04X: %4d %4d %4d %4d\n", 0x300 + i * 4, output[i], output[i + 1], output[i + 2], output[i + 3]);
	}

	printf("\n");

	printf("Wyniki hex:\n");
	for (i = 0; i < N; i = i + 4) {
		printf("%04X: %04X %04X %04X %04X\n", 0x300 + i * 4, output[i], output[i + 1], output[i + 2], output[i + 3]);
	}

	return 0;
}